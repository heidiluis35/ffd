package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Alumno
import com.example.data.repository.BibliotecaRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `launch MainActivity without crash`() {
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        assertNotNull(controller.get())
    }

    @Test
    fun `register and scan student test`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = BibliotecaRepository(context)

        val testAlumno = Alumno(
            uid = "TESTUID123",
            numeroControl = "20089999",
            nombre = "Estudiante de Prueba ITI",
            carrera = "Ing. en Sistemas Computacionales"
        )

        val regResult = repository.registerAlumno(testAlumno)
        assertTrue(regResult.isSuccess)

        val scanResult = repository.processNfcTag("TESTUID123")
        assertTrue(scanResult.isSuccess)

        val (alumno, registro) = scanResult.getOrThrow()
        assertEquals("TESTUID123", alumno.uid)
        assertEquals("entrada", registro.tipo)

        // Second scan should alternate to salida
        val scan2Result = repository.processNfcTag("TESTUID123")
        assertTrue(scan2Result.isSuccess)
        val (_, registro2) = scan2Result.getOrThrow()
        assertEquals("salida", registro2.tipo)
    }
}
