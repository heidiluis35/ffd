package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ItiNavyPrimary
import com.example.ui.theme.ItiOrangeAccent

@Composable
fun NfcSimulationDialog(
    onDismiss: () -> Unit,
    onSimulateScan: (String) -> Unit
) {
    var customUid by remember { mutableStateOf("") }

    val presetStudents = listOf(
        Triple("04A1B2C3", "Alejandro Ruiz Santiago", "Ing. Sistemas (Registrado)"),
        Triple("E2806894", "María Fernanda López", "Ing. Industrial (Registrado)"),
        Triple("1A2B3C4D", "Juan Carlos Toledo", "Ing. Eléctrica (Registrado)"),
        Triple("5E6F7A8B", "Ximena Morales Vásquez", "Gestión Empresarial (Registrado)"),
        Triple("DEADBEEF", "Tag Desconocido", "No registrado (Genera Error)")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Nfc,
                    contentDescription = null,
                    tint = ItiOrangeAccent,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Simulador de Lectura NFC",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Prueba el escaneo de credenciales RFID/NFC en el emulador seleccionando un tag de prueba:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(presetStudents.size) { index ->
                        val (uid, name, desc) = presetStudents[index]
                        val isUnknown = uid == "DEADBEEF"

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnknown) Color(0xFFFFF0F0) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSimulateScan(uid)
                                    onDismiss()
                                }
                                .testTag("sim_student_$index")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isUnknown) Icons.Default.Warning else Icons.Default.Badge,
                                    contentDescription = null,
                                    tint = if (isUnknown) Color(0xFFC0392B) else ItiNavyPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = name,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "$desc • UID: $uid",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = customUid,
                    onValueChange = { customUid = it.uppercase() },
                    label = { Text("O escribe un UID hexadecimal") },
                    placeholder = { Text("Ej: 04E5F6A7") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_uid_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (customUid.isNotBlank()) {
                        onSimulateScan(customUid)
                        onDismiss()
                    }
                },
                enabled = customUid.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ItiNavyPrimary),
                modifier = Modifier.testTag("submit_custom_uid")
            ) {
                Text("Escanear UID")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_sim_dialog")
            ) {
                Text("Cerrar")
            }
        }
    )
}
