package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF8DA9C4),
    onPrimary = Color(0xFF041933),
    primaryContainer = Color(0xFF0D3B66),
    onPrimaryContainer = Color(0xFFD6E4F0),
    secondary = ItiOrangeAccent,
    onSecondary = Color.White,
    secondaryContainer = ItiOrangeDark,
    onSecondaryContainer = Color(0xFFFFDBCF),
    background = DarkNavyBackground,
    surface = DarkNavySurface,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFCBD5E1)
)

private val LightColorScheme = lightColorScheme(
    primary = ItiNavyPrimary,
    onPrimary = Color.White,
    primaryContainer = ItiNavyContainer,
    onPrimaryContainer = ItiOnNavyContainer,
    secondary = ItiOrangeAccent,
    onSecondary = Color.White,
    secondaryContainer = ItiOrangeContainer,
    onSecondaryContainer = ItiOnOrangeContainer,
    background = Color(0xFFF4F6F9),
    surface = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = ItiSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep ITI brand colors consistent
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.primary.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
