package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ITI Brand Colors (Navy Blue + Tec Orange)
val ItiNavyPrimary = Color(0xFF0D3B66)
val ItiNavyDark = Color(0xFF081C30)
val ItiNavyContainer = Color(0xFFD6E4F0)
val ItiOnNavyContainer = Color(0xFF001F3F)

val ItiOrangeAccent = Color(0xFFF25C05)
val ItiOrangeDark = Color(0xFFC04600)
val ItiOrangeContainer = Color(0xFFFFDBCF)
val ItiOnOrangeContainer = Color(0xFF3B1000)

val ItiSurface = Color(0xFFF8FAFC)
val ItiSurfaceVariant = Color(0xFFE2E8F0)
val ItiCardBackground = Color(0xFFFFFFFF)

// Semantic status colors
val StatusSuccess = Color(0xFF1E824C)
val StatusSuccessContainer = Color(0xFFD4EDDA)
val StatusError = Color(0xFFC0392B)
val StatusErrorContainer = Color(0xFFFADBD8)

val DarkNavyBackground = Color(0xFF0B192C)
val DarkNavySurface = Color(0xFF1E3E62)
