package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.export.ExcelExporter
import com.example.data.model.Alumno
import com.example.data.model.Registro
import com.example.data.repository.BibliotecaRepository
import com.example.data.repository.DashboardStats
import com.example.data.repository.StudentNotFoundException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    data object StudentWaiting : Screen()
    data class StudentSuccess(val alumno: Alumno, val registro: Registro) : Screen()
    data class StudentError(val uid: String) : Screen()
    data object AdminLogin : Screen()
    data object AdminDashboard : Screen()
    data class AdminAddStudent(val prefilledUid: String = "") : Screen()
}

sealed class ExportState {
    data object Idle : ExportState()
    data object Loading : ExportState()
    data class Success(val uri: Uri, val message: String) : ExportState()
    data class Error(val message: String) : ExportState()
}

class BibliotecaViewModel(private val repository: BibliotecaRepository) : ViewModel() {

    private val _currentScreen = MutableStateFlow<Screen>(Screen.StudentWaiting)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _countdown = MutableStateFlow(4)
    val countdown: StateFlow<Int> = _countdown.asStateFlow()

    private var autoReturnJob: Job? = null

    // Real-time registrations and students
    val allRegistros: StateFlow<List<Registro>> = repository.getAllRegistrosFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayRegistros: StateFlow<List<Registro>> = repository.getRegistrosTodayFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAlumnos: StateFlow<List<Alumno>> = repository.getAllAlumnosFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined stats with student count
    val stats: StateFlow<DashboardStats> = combine(
        repository.getDashboardStats(),
        allAlumnos
    ) { currentStats, alumnos ->
        currentStats.copy(totalAlumnosRegistrados = alumnos.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // Search and filter in Admin Dashboard
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _showOnlyToday = MutableStateFlow(true)
    val showOnlyToday: StateFlow<Boolean> = _showOnlyToday.asStateFlow()

    // Filtered records flow
    val filteredRegistros: StateFlow<List<Registro>> = combine(
        allRegistros,
        todayRegistros,
        searchQuery,
        showOnlyToday
    ) { all, today, query, onlyToday ->
        val baseList = if (onlyToday) today else all
        if (query.isBlank()) {
            baseList
        } else {
            val q = query.trim().lowercase()
            baseList.filter {
                it.nombre.lowercase().contains(q) ||
                        it.numeroControl.lowercase().contains(q) ||
                        it.carrera.lowercase().contains(q) ||
                        it.alumnoUid.lowercase().contains(q)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Auth State
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn.asStateFlow()

    // Export State
    private val _exportState = MutableStateFlow<ExportState>(ExportState.Idle)
    val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

    // Add Student Form State
    private val _addStudentStatus = MutableStateFlow<String?>(null)
    val addStudentStatus: StateFlow<String?> = _addStudentStatus.asStateFlow()

    // Last scanned UID in kiosk (available to autofill when admin adds student)
    private val _lastCapturedUid = MutableStateFlow("")
    val lastCapturedUid: StateFlow<String> = _lastCapturedUid.asStateFlow()

    /**
     * Triggered when an NFC tag is read physically or simulated.
     */
    fun onNfcTagDetected(rawUid: String) {
        val cleanUid = rawUid.trim().replace(":", "").uppercase()
        if (cleanUid.isBlank()) return

        _lastCapturedUid.value = cleanUid

        // If currently on AddStudent screen, autofill the UID in that form!
        val current = _currentScreen.value
        if (current is Screen.AdminAddStudent) {
            _currentScreen.value = Screen.AdminAddStudent(prefilledUid = cleanUid)
            return
        }

        // Otherwise, process as Student attendance
        processAttendance(cleanUid)
    }

    private fun processAttendance(uid: String) {
        autoReturnJob?.cancel()

        viewModelScope.launch {
            val result = repository.processNfcTag(uid)
            result.fold(
                onSuccess = { (alumno, registro) ->
                    _currentScreen.value = Screen.StudentSuccess(alumno, registro)
                    startCountdownAutoReturn()
                },
                onFailure = { error ->
                    if (error is StudentNotFoundException) {
                        _currentScreen.value = Screen.StudentError(error.uid)
                    } else {
                        _currentScreen.value = Screen.StudentError(uid)
                    }
                    startCountdownAutoReturn(seconds = 5)
                }
            )
        }
    }

    private fun startCountdownAutoReturn(seconds: Int = 4) {
        autoReturnJob?.cancel()
        _countdown.value = seconds
        autoReturnJob = viewModelScope.launch {
            for (i in seconds downTo 1) {
                _countdown.value = i
                delay(1000)
            }
            returnToWaitingScreen()
        }
    }

    fun returnToWaitingScreen() {
        autoReturnJob?.cancel()
        _currentScreen.value = Screen.StudentWaiting
    }

    fun navigateToAdminLogin() {
        autoReturnJob?.cancel()
        _loginError.value = null
        if (_isAdminLoggedIn.value) {
            _currentScreen.value = Screen.AdminDashboard
        } else {
            _currentScreen.value = Screen.AdminLogin
        }
    }

    fun loginAdmin(email: String, pass: String) {
        viewModelScope.launch {
            _isLoggingIn.value = true
            _loginError.value = null
            val result = repository.loginAdmin(email, pass)
            _isLoggingIn.value = false
            result.fold(
                onSuccess = { success ->
                    if (success) {
                        _isAdminLoggedIn.value = true
                        _currentScreen.value = Screen.AdminDashboard
                    } else {
                        _loginError.value = "Credenciales incorrectas"
                    }
                },
                onFailure = { ex ->
                    _loginError.value = ex.localizedMessage ?: "Error de autenticación"
                }
            )
        }
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        _currentScreen.value = Screen.StudentWaiting
    }

    fun navigateToDashboard() {
        _currentScreen.value = Screen.AdminDashboard
    }

    fun navigateToAddStudent(prefilledUid: String = "") {
        _addStudentStatus.value = null
        val uidToUse = if (prefilledUid.isNotBlank()) prefilledUid else _lastCapturedUid.value
        _currentScreen.value = Screen.AdminAddStudent(uidToUse)
    }

    fun registerNewStudent(uid: String, numControl: String, nombre: String, carrera: String) {
        if (uid.isBlank() || numControl.isBlank() || nombre.isBlank() || carrera.isBlank()) {
            _addStudentStatus.value = "Por favor completa todos los campos requeridos"
            return
        }

        viewModelScope.launch {
            val alumno = Alumno(
                uid = uid.trim().replace(":", "").uppercase(),
                numeroControl = numControl.trim(),
                nombre = nombre.trim(),
                carrera = carrera.trim()
            )
            val result = repository.registerAlumno(alumno)
            result.fold(
                onSuccess = {
                    _addStudentStatus.value = "SUCCESS"
                    _lastCapturedUid.value = ""
                },
                onFailure = { ex ->
                    _addStudentStatus.value = "Error: ${ex.message}"
                }
            )
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setShowOnlyToday(onlyToday: Boolean) {
        _showOnlyToday.value = onlyToday
    }

    fun exportToExcel(context: Context) {
        viewModelScope.launch {
            _exportState.value = ExportState.Loading
            val records = allRegistros.value
            if (records.isEmpty()) {
                _exportState.value = ExportState.Error("No hay registros disponibles para exportar")
                return@launch
            }

            val result = ExcelExporter.exportRegistrosToExcel(context, records)
            result.fold(
                onSuccess = { uri ->
                    _exportState.value = ExportState.Success(
                        uri = uri,
                        message = "Archivo Excel generado con éxito en Descargas"
                    )
                },
                onFailure = { error ->
                    _exportState.value = ExportState.Error(
                        message = "Error al exportar: ${error.localizedMessage ?: error.message}"
                    )
                }
            )
        }
    }

    fun clearExportState() {
        _exportState.value = ExportState.Idle
    }
}

class BibliotecaViewModelFactory(private val repository: BibliotecaRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BibliotecaViewModel::class.java)) {
            return BibliotecaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
