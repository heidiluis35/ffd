package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.Alumno
import com.example.data.model.Registro
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Calendar

data class DashboardStats(
    val entradasHoy: Int = 0,
    val salidasHoy: Int = 0,
    val enSalaAhora: Int = 0,
    val totalAlumnosRegistrados: Int = 0
)

class StudentNotFoundException(val uid: String) : Exception("Credencial no vinculada a ningún alumno")

class BibliotecaRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val alumnoDao = db.alumnoDao()
    private val registroDao = db.registroDao()

    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var firestore: FirebaseFirestore? = null
    private var auth: FirebaseAuth? = null

    init {
        initFirebaseIfAvailable()
        coroutineScope.launch {
            seedSampleDataIfEmpty()
            listenToFirestoreSync()
        }
    }

    private fun initFirebaseIfAvailable() {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                firestore = FirebaseFirestore.getInstance()
                auth = FirebaseAuth.getInstance()
                Log.d("BibliotecaRepo", "Firebase initialized successfully")
            } else {
                Log.w("BibliotecaRepo", "Firebase not initialized in this environment, using local persistence")
            }
        } catch (e: Exception) {
            Log.e("BibliotecaRepo", "Firebase init error: ${e.message}")
        }
    }

    private suspend fun seedSampleDataIfEmpty() {
        val sampleStudents = listOf(
            Alumno(
                uid = "04A1B2C3",
                numeroControl = "20080123",
                nombre = "Alejandro Ruiz Santiago",
                carrera = "Ing. en Sistemas Computacionales"
            ),
            Alumno(
                uid = "E2806894",
                numeroControl = "21080456",
                nombre = "María Fernanda López Gómez",
                carrera = "Ing. Industrial"
            ),
            Alumno(
                uid = "1A2B3C4D",
                numeroControl = "19080789",
                nombre = "Juan Carlos Toledo Marín",
                carrera = "Ing. Eléctrica"
            ),
            Alumno(
                uid = "5E6F7A8B",
                numeroControl = "22080312",
                nombre = "Ximena Morales Vásquez",
                carrera = "Ing. en Gestión Empresarial"
            ),
            Alumno(
                uid = "9C8B7A6F",
                numeroControl = "20080991",
                nombre = "Diego Armando Pineda Cruz",
                carrera = "Ing. Electrónica"
            )
        )

        for (student in sampleStudents) {
            val existing = alumnoDao.getAlumnoByUid(student.uid)
            if (existing == null) {
                alumnoDao.insertAlumno(student)
                // Sync to Firestore if ready
                firestore?.collection("alumnos")?.document(student.uid)?.set(student.toMap())
            }
        }
    }

    private fun listenToFirestoreSync() {
        val fs = firestore ?: return

        // Sync Alumnos from Firestore
        try {
            fs.collection("alumnos").addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                coroutineScope.launch {
                    val remoteAlumnos = snapshot.documents.mapNotNull { doc ->
                        val data = doc.data ?: return@mapNotNull null
                        Alumno.fromMap(data)
                    }
                    if (remoteAlumnos.isNotEmpty()) {
                        alumnoDao.insertAll(remoteAlumnos)
                    }
                }
            }

            // Sync Registros from Firestore
            fs.collection("registros")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(200)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    coroutineScope.launch {
                        val remoteRegistros = snapshot.documents.mapNotNull { doc ->
                            val data = doc.data ?: return@mapNotNull null
                            Registro.fromMap(doc.id, data)
                        }
                        if (remoteRegistros.isNotEmpty()) {
                            registroDao.insertAll(remoteRegistros)
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e("BibliotecaRepo", "Firestore snapshot listener error: ${e.message}")
        }
    }

    private fun getStartOfDayMillis(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    suspend fun processNfcTag(rawUid: String): Result<Pair<Alumno, Registro>> = withContext(Dispatchers.IO) {
        val cleanUid = rawUid.trim().replace(":", "").uppercase()

        // 1. Search locally in Room
        var alumno = alumnoDao.getAlumnoByUid(cleanUid)

        // 2. If not found locally, query Firestore
        if (alumno == null && firestore != null) {
            try {
                val doc = firestore!!.collection("alumnos").document(cleanUid).get().await()
                if (doc.exists() && doc.data != null) {
                    alumno = Alumno.fromMap(doc.data!!)
                    alumnoDao.insertAlumno(alumno)
                }
            } catch (e: Exception) {
                Log.w("BibliotecaRepo", "Error searching student in Firestore: ${e.message}")
            }
        }

        if (alumno == null) {
            return@withContext Result.failure(StudentNotFoundException(cleanUid))
        }

        // 3. Determine if Entrada or Salida
        val startOfDay = getStartOfDayMillis()
        val latestRegistroToday = registroDao.getLatestRegistroToday(cleanUid, startOfDay)

        val nextTipo = if (latestRegistroToday == null || latestRegistroToday.tipo.equals("salida", ignoreCase = true)) {
            "entrada"
        } else {
            "salida"
        }

        val newRegistro = Registro(
            alumnoUid = cleanUid,
            numeroControl = alumno.numeroControl,
            nombre = alumno.nombre,
            carrera = alumno.carrera,
            timestamp = System.currentTimeMillis(),
            tipo = nextTipo
        )

        // 4. Save to Room
        registroDao.insertRegistro(newRegistro)

        // 5. Save to Firestore
        firestore?.let { fs ->
            try {
                fs.collection("registros").document(newRegistro.id).set(newRegistro.toMap())
            } catch (e: Exception) {
                Log.w("BibliotecaRepo", "Failed to sync registro to Firestore: ${e.message}")
            }
        }

        Result.success(Pair(alumno, newRegistro))
    }

    suspend fun registerAlumno(alumno: Alumno): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val formattedUid = alumno.uid.trim().replace(":", "").uppercase()
            val cleanAlumno = alumno.copy(uid = formattedUid)

            // Save to Room
            alumnoDao.insertAlumno(cleanAlumno)

            // Save to Firestore
            firestore?.let { fs ->
                fs.collection("alumnos").document(formattedUid).set(cleanAlumno.toMap()).await()
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getAllRegistrosFlow(): Flow<List<Registro>> = registroDao.getAllRegistros()

    fun getRegistrosTodayFlow(): Flow<List<Registro>> = registroDao.getRegistrosToday(getStartOfDayMillis())

    fun getAllAlumnosFlow(): Flow<List<Alumno>> = alumnoDao.getAllAlumnos()

    fun getDashboardStats(): Flow<DashboardStats> {
        val startOfDay = getStartOfDayMillis()
        return registroDao.getRegistrosToday(startOfDay).map { todayList ->
            val entradas = todayList.count { it.tipo.equals("entrada", ignoreCase = true) }
            val salidas = todayList.count { it.tipo.equals("salida", ignoreCase = true) }
            val enSala = (entradas - salidas).coerceAtLeast(0)
            DashboardStats(
                entradasHoy = entradas,
                salidasHoy = salidas,
                enSalaAhora = enSala,
                totalAlumnosRegistrados = 0
            )
        }
    }

    suspend fun getAlumnoByUid(uid: String): Alumno? = withContext(Dispatchers.IO) {
        val cleanUid = uid.trim().replace(":", "").uppercase()
        alumnoDao.getAlumnoByUid(cleanUid)
    }

    suspend fun loginAdmin(email: String, pass: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            // Check for standard ITI credentials or Firebase Auth
            val isDemoAdmin = (email.trim().equals("admin@itistmo.edu.mx", ignoreCase = true) && pass == "admin123") ||
                    (email.trim().equals("admin", ignoreCase = true) && pass == "admin")

            if (isDemoAdmin) {
                return@withContext Result.success(true)
            }

            // Real Firebase Auth
            if (auth != null) {
                auth!!.signInWithEmailAndPassword(email, pass).await()
                Result.success(true)
            } else {
                // If Firebase Auth is not configured with users, accept ITI admin credential
                Result.success(isDemoAdmin)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
